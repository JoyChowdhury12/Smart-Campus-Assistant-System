# Smart Campus Assistance System

Live site: https://smart-campus-assistant-ashy.vercel.app

React + Vite front end with a serverless API (`api/rpc.js`) and Upstash Redis storage, so every device sees the same data.

## Run locally
    npm install
    npm run dev        # API runs in-memory locally (resets on restart)

## Demo accounts
- Student: student@campus.edu / student123
- Admin: admin@campus.edu / admin123

## Deploy to Vercel (shared database)
1. Push to GitHub and import the repo in Vercel (Framework: Vite).
2. In the Vercel project: Storage -> Create Database -> Upstash for Redis (free) -> connect it to this project.
   This adds KV_REST_API_URL / KV_REST_API_TOKEN automatically.
3. Optional: add an AUTH_SECRET environment variable (any long random string).
4. Redeploy (Deployments -> Redeploy). Demo data is created on first use.

## Features
Core: registration/login, submit request, categories, view requests, status tracking, admin dashboard, update status, search/filter/sort.
Advanced: priority management, dashboard stats + charts, department assignment, notifications on status change (live polling).
Bonus: weighted, explainable priority recommendation (src/priority.js).
Security: hashed passwords (scrypt), signed session tokens, server-side role checks.
